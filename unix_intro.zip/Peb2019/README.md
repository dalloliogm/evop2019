# peb_unix_intro
Materials for the Unix Intro workshop at the Programming for Evolutionary Course in Leipzig


## How to start

Move to the exercise folder, and open the file for the first exercise:

	$: cd exercises
	$: head 1_browsing_textfiles.txt
