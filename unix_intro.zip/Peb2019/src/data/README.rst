data folder, containing exercise files
